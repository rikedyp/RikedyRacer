This pack contains 3030 images

Every color has all the cars in all views and resolution

Filename structure:
------------------------
cxx_sxx_view_framenr.png

c stands for the color of the car
S is for the resolution of the image
view is the orientation of the camera
framenr is the carmodel and rotation


Color:
---------------
c01: red
c02: light blue
c04: mid grey
c05: green
c07: black
c08: pink
c09: white
c10: yellow
c11: orange
c12: purple

resolution:
-----------------
s128: 128x128 pixels

view:
---------------------
iso:  Isometric view

framenr:
----------------------------------------
every car has 16 frames for its rotation.
The first frame of every car of facing sourth or pointing to the bottom left. every following frame is a rotation 22.5 degrees clockwise.
0001-0016: Basic sedan car 
0017-0032: Sport coupe
0033-0048: Compact city car
0049-0064: Hothatch car
0065-0080: Small delivery car
0081-0096: Mini mpv
0097-0112: Station wagon
0113-0128: MPV
0129-0144: Minibus
0145-0160: Delivery van
0161-0176: Pickup truck
0177-0191: Small pickup car
0192-0207: German sportscar
0208-0223: Italian horse Sportscar
0224-0239: Italian Bull Sportscar
0240-0255: Formula car
0256-0271: Group C
0272-0287: Group C Badass
0288-0303: Kart
